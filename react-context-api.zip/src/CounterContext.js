import React, { createContext } from 'react';

const counterContext = createContext(5);

export default counterContext;